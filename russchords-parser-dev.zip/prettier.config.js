export default {
	singleQuote: true,
	semi: true,
	bracketSpacing: true,
	jsxBracketSameLine: false,
	useTabs: true,
	printWidth: 120,
};
